﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class demo_02_controls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        TextBox txtMyText = new TextBox();
        txtMyText.ID = "txtMyText";
        txtMyText.TextMode = TextBoxMode.SingleLine;
      
        Button btnSubmit = new Button();
        btnSubmit.ID = "btnSubmit";
        btnSubmit.UseSubmitBehavior = true;
        btnSubmit.Text = "Send";
        
        Button btnReset = new Button();
        btnReset.ID = "btnReset"; 
        btnReset.UseSubmitBehavior = false;
        btnReset.Text = "Reset";

        form1.Controls.Add(txtMyText);
        form1.Controls.Add(btnSubmit);
        form1.Controls.Add(btnReset);

    }
}
