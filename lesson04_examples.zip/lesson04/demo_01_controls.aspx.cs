﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class demo_01_controls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtMyText.Text = "Welcome to ...";

    }
}
