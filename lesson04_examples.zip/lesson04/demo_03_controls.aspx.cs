﻿using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class demo_03_controls : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        txtMyText.Text = "Welcome to ...";
        btnSubmit.Text = "Send content";
        btnReset.Text = "Reset content";

    }
}
