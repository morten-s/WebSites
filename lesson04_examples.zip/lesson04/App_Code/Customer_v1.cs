﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer_v1
{

    private int customerId;
    public int CustomerId
    {
        get { return customerId; }
    }
    
    private string firstname;
    public string Firstname
    {
        set { firstname = value; }
        get { return firstname; }
    }

    private string lastname;
    public string Lastname
    {
        set { lastname = value; }
        get { return lastname; }
    }

    private string address;
    public string Address
    {
        set { address = value; }
        get { return address; }
    }


    private string zipcode;
    public string Zipcode
    {
        set { zipcode = value; }
        get { return zipcode; }
    }

    private string city;
    public string City
    {
        set { city = value; }
        get { return city; }
    }

    private string email;
    public string Email
    {
        set { email = value; }
        get { return email; }
    }

    private string phone;
    public string Phone
    {
        set
        {
            if (value.Length > 7)
            {
                phone = value;
            }
            else
            {
                throw new Exception("Phone number is not valid");
            }
        }
        get { return phone; }
    }



	public Customer_v1(int customerId, string firstname, string lastname, string address, string zipcode, string city, string email, string phone)
	{
        this.customerId = customerId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.address = address;
        this.zipcode = zipcode;
        this.city = city;
        this.email = email;
        this.Phone = phone;

	}
}