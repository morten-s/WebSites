﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Employee : Person
{

    private int employeeId;
    public int EmployeeId
    {
        get { return employeeId; }
    }
    
  

    private string initials;
    public string Initials
    {
        set { initials = value; }
        get { return initials; }
    }

    public Employee(int employeeId, string firstname, string lastname, string initials, string phone)
        : base(firstname, lastname, phone)
	{
        this.employeeId = employeeId;
        this.initials  = initials;

	}
}