﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Model
/// </summary>
public class Service
{
	public Service()
	{
		prices = new Dictionary<string, decimal>();
        pets = new List<Pet>();

	}

    private Dictionary<string, decimal> prices;  
    public Dictionary<string, decimal> Prices { get { return prices; } }
    public Customer c1, c2;

    private List<Pet> pets;
    public List<Pet> Pets { get { return pets; } }

    public void StartUp() 
    {
      // add prices to the dictionary, prices
      prices.Add("Dog", 120);
      prices.Add("Cat", 160);
      prices.Add("Snake", 120);
      prices.Add("Guinea pig", 60);
      prices.Add("Canary", 50);

      // create customers
      c1 = new Customer(1001, "Susan", "Peterson", "Borgergade 45", 
                                 "8000", "Aarhus", "supe@xmail.dk", "21212121");
      c2 = new Customer(1002, "Brian", "Smith", "Allegade 108",
                                 "8000", "Aarhus", "brsm@xmail.dk", "45454545");

      // create employees
      Employee e1 = new Employee(001, "Laura", "Johnson", "lajo", "31313131");
      Employee e2 = new Employee(002, "Joe", "McGuire", "jomgm", "52525252");

        Pet p1 = new Pet("Dog", "Hamlet", new DateTime(2011, 9, 2), new DateTime(2011, 9, 20), c1);
        p1.RecievedBy = e1;
        c1.addPet(p1);
        
        Pet p2 = new Pet("Dog", "Samson", new DateTime(2011, 9, 14), new DateTime(2011, 9, 21), c1);
        p2.RecievedBy = e2;
        c1.addPet(p2);

        Pet p3 = new Pet("Cat", "Darla", new DateTime(2011, 9, 7), new DateTime(2011, 9, 10), c2);
        p3.RecievedBy = e1;
        c2.addPet(p3);


        // add Pets to list of Pet, pets
        pets.Add(p1);
        pets.Add(p2);
        pets.Add(p3);
    }
}