﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Employee_v1
{

    private int employeeId;
    public int EmployeeId
    {
        get { return employeeId; }
    }
    
    private string firstname;
    public string Firstname
    {
        set { firstname = value; }
        get { return firstname; }
    }

    private string lastname;
    public string Lastname
    {
        set { lastname = value; }
        get { return lastname; }
    }


    private string phone;
    public string Phone
    {
        set
        {
            if (value.Length > 7)
            {
                phone = value;
            }
            else
            {
                throw new Exception("Phone number is not valid");
            }
        }
        get { return phone; }
    }

    private string initials;
    public string Initials
    {
        set { initials = value; }
        get { return initials; }
    }

    public Employee_v1(int employeeId, string firstname, string lastname, string initials, string phone)
	{
        this.employeeId = employeeId;
        this.firstname = firstname;
        this.lastname = lastname;
        this.Phone = phone;
        this.initials  = initials;

	}
}