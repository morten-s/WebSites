﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Model
/// </summary>
public class Service_v1
{
	public Service_v1()
	{
		prices = new Dictionary<string, decimal>();
        pets = new List<Pet>();

	}

    private Dictionary<string, decimal> prices;  
    public Dictionary<string, decimal> Prices { get { return prices; } }

    private List<Pet> pets;
    public List<Pet> Pets { get { return pets; } }

    public void StartUp() 
    {
      // add prices to the dictionary, prices
      prices.Add("Dog", 120);
      prices.Add("Cat", 160);
      prices.Add("Snake", 120);
      prices.Add("Guinea pig", 60);
      prices.Add("Canary", 50);

      // create customers
      Customer c1 = new Customer(1001, "Susan", "Peterson", "Borgergade 45", 
                                 "8000", "Aarhus", "supe@xmail.dk", "21212121");
      Customer c2 = new Customer(1002, "Brian", "Smith", "Allegade 108",
                                 "8000", "Aarhus", "brsm@xmail.dk", "45454545");

      Pet p1 = new Pet("Dog", "Hamlet", new DateTime(2011, 9, 2), new DateTime(2011, 9, 20), c1);
      Pet p2 = new Pet("Dog", "Samson", new DateTime(2011, 9, 14), new DateTime(2011, 9, 21), c1);
      Pet p3 = new Pet("Cat", "Darla", new DateTime(2011, 9, 7), new DateTime(2011, 9, 10), c2);
      // add Pets to list of Pet, pets
      pets.Add(p1);
      pets.Add(p2);
      pets.Add(p3);
    }
}