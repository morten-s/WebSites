﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

public class Person
{

   
    private string firstname;
    public string Firstname
    {
        set { firstname = value; }
        get { return firstname; }
    }

    private string lastname;
    public string Lastname
    {
        set { lastname = value; }
        get { return lastname; }
    }


    private string phone;
    public string Phone
    {
        set
        {
            if (value.Length > 7)
            {
                phone = value;
            }
            else
            {
                throw new Exception("Phone number is not valid");
            }
        }
        get { return phone; }
    }




    public Person(string firstname, string lastname, string phone)
	{
        this.firstname = firstname;
        this.lastname = lastname;
        this.Phone  = phone;
	}
}