﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Pet
/// </summary>
public class Pet
{
    private string species;
    public string Species {
        set { species = value; }
        get { return species; }
    }

    private string name;
    public string Name
    {
        set { name = value; }
        get { return name; }
    }

    private DateTime startDate;
    public DateTime StartDate
    {
        set { startDate = value; }
        get { return startDate; }
    }

    private DateTime endDate;
    public DateTime EndDate
    {
        set { endDate = value; }
        get { return endDate; }
    }

    private Customer owner;
    public Customer Owner
    {
        set { owner = value; }
        get { return owner; }
    }

    private Employee recievedBy;
    public Employee RecievedBy
    {
        set { recievedBy = value; }
        get { return recievedBy; }
    }
    
    
    public Pet(string species, string name, DateTime startDate, DateTime endDate, Customer owner)
	{
        this.species = species;
        this.name = name;
        this.startDate = startDate;
        this.endDate = endDate;
        this.owner = owner;
	}


}