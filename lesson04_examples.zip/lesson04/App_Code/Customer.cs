﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for Customer
/// </summary>
public class Customer : Person
{

    private int customerId;
    public int CustomerId
    {
        get { return customerId; }
    }

    private string address;
    public string Address
    {
        set { address = value; }
        get { return address; }
    }


    private string zipcode;
    public string Zipcode
    {
        set { zipcode = value; }
        get { return zipcode; }
    }

    private string city;
    public string City
    {
        set { city = value; }
        get { return city; }
    }

    private string email;
    public string Email
    {
        set { email = value; }
        get { return email; }
    }

    private List<Pet> pets;
    public List<Pet> Pets
    {
        get { return pets; }
    }

    
	public Customer(int customerId, string firstname, string lastname, string address, string zipcode, string city, string email, string phone)
        : base (firstname, lastname, phone)
	{
        this.customerId = customerId;
        this.address = address;
        this.zipcode = zipcode;
        this.city = city;
        this.email = email;

        this.pets = new List<Pet>(); 
    }


    public void addPet(Pet pet) {
        pets.Add(pet);
    }
}