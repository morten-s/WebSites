﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class example03 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Product glass = new Product("Wine glass");
        glass.Price = 66.00;
        glass.ImageURL = "grandcru.jpg";

        string html = glass.GetHtml();
        ltrProduct1.Text = html;

        Product bin = new Product("Kitchen Garbage", 425.00, "bin_35l.jpg");
        ltrProduct2.Text = bin.GetHtml();

        Product knife = new Product("Steelline", 54.50, "st_knife.jpg");
        ltrProduct3.Text = knife.GetHtml();
    }

    protected void BtnShowAll_Click(object sender, EventArgs e)
    {
        
    }
}